fdaSP guide — progetto autonomo R/RStudio

1. Aprire fdaSP-guide.Rproj.
2. Installare fdaSP, rmarkdown, knitr, ggplot2 e xml2 se mancanti.
   Gli esempi sono verificati con fdaSP 1.1.3 fornito dall'autore.
3. Eseguire source("build.R") dalla console R. Quarto è incluso in RStudio.
4. Aprire docs/index.html oppure vignettes/fdasp-guide.html.

Modificare chapters/*.Rmd per gli esempi e le spiegazioni.
Modificare website/index.qmd, website/reference.qmd e website/_quarto.yml
per homepage, indice delle funzioni e navigazione. Le altre pagine qmd sono generate.
Bibliografia: references.bib. Stile: website/assets/styles.css.
I dati dell'esempio applicativo sono in data/inflation-Q.RData.
Gli originali del repository sono conservati in archive/ senza modifiche.
Il build esegue gli esempi una volta, crea la vignetta e il sito, controlla i link.
Nessun Python è necessario. Nessuna pubblicazione automatica viene eseguita.

GitHub Pages: caricare la cartella docs nella root del repository
maurobernardi/fdaSP; Settings > Pages > Deploy from a branch > main > /docs.
Non eliminare il vecchio README né i dati per pubblicare il nuovo sito.

La cartella library contiene la copia locale del pacchetto corretta e verificata
per compilare questa guida su questo Mac. Non caricarla su GitHub o CRAN.
Il build la usa se presente; la libreria R globale non è stata modificata.
Su altri computer installare il pacchetto aggiornato dalla sorgente.

Dopo aver aggiornato il pacchetto sorgente, in una nuova sessione R eseguire
source("scripts/install-local.R") per aggiornare library, poi source("build.R").
Il resoconto delle correzioni e i log sono in maintainer/RESOCONTO_PACCHETTO.txt.

RECUPERO MATERIALE ORIGINALE
chapters/inflation-comparisons.Rmd esegue tutte le analisi del README originale.
Sono richiesti anche glmnet, leaps, BMS e corrplot (solo per la guida).
L'enumerazione BMS visita i 262144 modelli dei 18 predittori a un ritardo.
Il capitolo inflation.Rmd contiene l'esempio cronologico aggiuntivo.
