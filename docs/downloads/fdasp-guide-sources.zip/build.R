# Aprire fdaSP-guide.Rproj in RStudio, poi eseguire: source("build.R")
# Contenuti: chapters/*.Rmd; homepage: website/index.qmd.
# Il sito viene compilato localmente, senza pubblicare su GitHub.
local({
  source_files <- as.character(unlist(lapply(sys.frames(), function(frame) frame$ofile)))
  candidates <- source_files[basename(source_files) == "build.R"]
  if (length(candidates)) {
    root <- dirname(normalizePath(tail(candidates, 1), mustWork = TRUE))
  } else {
    cli <- grep("^--file=", commandArgs(), value = TRUE)
    root <- if (length(cli)) dirname(normalizePath(sub("^--file=", "", cli[1]))) else getwd()
  }
  local_library <- file.path(root,"library")
  if (dir.exists(local_library)) .libPaths(c(local_library,.libPaths()))
  old_wd <- setwd(root)
  on.exit(setwd(old_wd), add = TRUE)
  required <- c("fdaSP", "rmarkdown", "knitr", "ggplot2", "xml2", "Matrix", "glmnet", "leaps", "BMS", "corrplot")
  missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) stop("Installare prima i pacchetti: ", paste(missing, collapse = ", "))
  if (utils::packageVersion("fdaSP") != "1.1.3") {
    message("Nota: esempi verificati con fdaSP 1.1.3; versione in uso: ",
            utils::packageVersion("fdaSP"))
  }

  # Cerca Quarto nel PATH o nella copia fornita con RStudio su macOS.
  quarto_candidates <- c(Sys.getenv("QUARTO_PATH"), Sys.getenv("RSTUDIO_QUARTO"),
                         unname(Sys.which("quarto")),
                         "/Applications/RStudio.app/Contents/Resources/app/quarto/bin/quarto")
  quarto_candidates <- quarto_candidates[nzchar(quarto_candidates)]
  quarto_candidates <- vapply(quarto_candidates, function(p) {
    if (dir.exists(p)) file.path(p, if (.Platform$OS.type == "windows") "quarto.exe" else "quarto") else p
  }, character(1))
  available <- quarto_candidates[file.exists(quarto_candidates)]
  if (!length(available)) stop("Quarto non trovato. Installare Quarto o impostare QUARTO_PATH.")
  quarto <- normalizePath(available[1])
  if (!nzchar(Sys.getenv("RSTUDIO_PANDOC"))) {
    pandoc_candidates <- c(file.path(dirname(quarto), "tools", "aarch64"),
                            file.path(dirname(quarto), "tools", "x86_64"),
                            file.path(dirname(quarto), "tools"))
    pandoc <- pandoc_candidates[file.exists(file.path(pandoc_candidates, "pandoc"))]
    if (length(pandoc)) {
      Sys.setenv(RSTUDIO_PANDOC = pandoc[1])
      on.exit(Sys.unsetenv("RSTUDIO_PANDOC"), add = TRUE)
    }
  }
  if (!rmarkdown::pandoc_available()) stop("Pandoc non trovato: eseguire da RStudio oppure impostare RSTUDIO_PANDOC.")

  dir.create("results", showWarnings = FALSE)
  dir.create("vignettes/assets", recursive = TRUE, showWarnings = FALSE)
  dir.create("website/downloads", recursive = TRUE, showWarnings = FALSE)
  copy_file <- function(from, to) {
    if (!all(file.copy(from, to, overwrite = TRUE))) stop("Copia non riuscita: ", paste(from, collapse = ", "))
  }
  read_text <- function(path) paste(readLines(path, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
  chapter_names <- c("linear", "scalar-function", "function-function", "inflation-comparisons", "inflation", "theory")
  chapter_files <- file.path("chapters", paste0(chapter_names, ".Rmd"))
  # Questi file sono sorgenti manuali e non vengono mai rigenerati.
  manual_files <- c("website/index.qmd", "website/reference.qmd", "website/_quarto.yml")
  manual_hash <- tools::md5sum(manual_files)

  message("1/4 — Preparo la vignetta dai capitoli R Markdown.")
  copy_file(file.path("website/assets", c("unipd-seal.png", "styles.css")), "vignettes/assets")
  copy_file("references.bib", "vignettes/references.bib")
  chapters <- vapply(chapter_files, read_text, character(1))
  marked <- paste0("<!-- fdasp-chapter:", chapter_names, " -->\n\n", chapters)
  marked <- gsub("# References {.unnumbered}", "", marked, fixed=TRUE)
  vignette <- paste(c(read_text("chapters/00-introduction.Rmd"), marked, "# References {.unnumbered}"), collapse = "\n\n")
  writeLines(vignette, "vignettes/fdasp-guide.Rmd", useBytes = TRUE)

  message("2/4 — Eseguo gli esempi e compilo la vignetta HTML.")
  example_env <- new.env(parent = globalenv())
  rmarkdown::render("vignettes/fdasp-guide.Rmd", envir = example_env, quiet = TRUE)
  knitr::purl("vignettes/fdasp-guide.Rmd", output = "scripts/all-examples.R",
              documentation = 1, quiet = TRUE)
  write.csv(example_env$convergence_table,"results/convergence.csv",row.names=FALSE)
  write.csv(example_env$inflation_results,"results/inflation.csv",row.names=FALSE)
  write.csv(example_env$df_paths,"results/linear-dof.csv",row.names=FALSE)
  for (name in c("one_selected","subset_criteria","pilot_table","adaptive_selected",
                 "bma_comparison","ols_comparison","fdasp_cv_plot")) {
    write.csv(get(name,example_env),file.path("results",paste0("original-",name,".csv")),
              row.names=FALSE)
  }
  writeLines(capture.output(sessionInfo()), "results/session-info.txt")

  message("3/4 — Aggiorno le sole pagine derivate dai capitoli.")
  knitted <- readLines("vignettes/fdasp-guide.md", warn = FALSE, encoding = "UTF-8")
  starts <- match(paste0("<!-- fdasp-chapter:", chapter_names, " -->"), knitted)
  if (anyNA(starts) || is.unsorted(starts)) stop("Marcatori dei capitoli mancanti o fuori ordine.")
  ends <- c(starts[-1] - 1L, length(knitted))
  for (i in seq_along(chapter_names)) {
    body <- knitted[seq.int(starts[i] + 1L, ends[i])]
    title_line <- grep("^# ", body)[1]
    if (is.na(title_line)) stop("Manca il titolo del capitolo: ", chapter_names[i])
    title <- sub("^# ", "", body[title_line])
    body <- body[-seq_len(title_line)]
    # Promuovi i titoli solo fuori dai blocchi di codice.
    in_code <- FALSE
    for (j in seq_along(body)) {
      if (grepl("^```", body[j])) in_code <- !in_code
      if (!in_code && grepl("^#{2,6} ", body[j])) body[j] <- sub("^#", "", body[j])
    }
    if (chapter_names[i] != "theory" && any(grepl("@[A-Za-z]",body))) body <- c(body,"", "# References {.unnumbered}")
    header <- c("---", paste0("title: ", encodeString(title, quote = '"')), "---", "",
                 paste0("<!-- Generato da chapters/", chapter_names[i], ".Rmd: modificare quel file, poi source(\"build.R\"). -->"), "")
    writeLines(c(header, body), file.path("website", paste0(chapter_names[i], ".qmd")), useBytes = TRUE)
  }
  copy_file("vignettes/references.bib", "website/references.bib")
  figures <- list.files("vignettes/fdasp-guide_files", recursive = TRUE, full.names = TRUE)
  for (f in figures) {
    target <- sub("^vignettes/", "website/", f)
    dir.create(dirname(target), recursive = TRUE, showWarnings = FALSE)
    copy_file(f, target)
  }
  copy_file("vignettes/fdasp-guide.html", "website/downloads/fdasp-guide.html")
  copy_file("scripts/all-examples.R", "website/downloads/all-examples.R")
  if (!identical(manual_hash, tools::md5sum(manual_files))) stop("Un sorgente manuale è stato alterato durante il build.")

  source_files <- c("build.R","README.txt","fdaSP-guide.Rproj","references.bib",
                    list.files("chapters",full.names=TRUE),
                    list.files("scripts",full.names=TRUE),
                    list.files("data",full.names=TRUE),
                    list.files("archive",full.names=TRUE),
                    manual_files,list.files("website/assets",full.names=TRUE))
  source_zip <- "website/downloads/fdasp-guide-sources.zip"
  if (file.exists(source_zip)) unlink(source_zip)
  utils::zip(source_zip,source_files,flags="-q")
  message("4/4 — Compilo il sito Quarto e verifico i collegamenti.")
  status <- system2(quarto, c("render", shQuote(normalizePath("website"))))
  if (!identical(status, 0L)) stop("Compilazione Quarto fallita (codice ", status, ").")
  file.create("docs/.nojekyll", showWarnings = FALSE)
  sys.source("scripts/check_links.R", envir = environment())
  check_local_links("docs")
  message("Completato. Sito: ", file.path(root, "docs/index.html"),
          "\nVignetta: ", file.path(root, "vignettes/fdasp-guide.html"))
})
