# Verifica file, immagini e ancore locali con xml2; non richiede Python.
check_local_links <- function(directory = "docs") {
  root <- normalizePath(directory, mustWork = TRUE)
  files <- list.files(root, pattern = "\\.html$", recursive = TRUE, full.names = TRUE)
  documents <- lapply(files, xml2::read_html)
  names(documents) <- normalizePath(files)
  ids <- lapply(documents, function(doc) xml2::xml_attr(xml2::xml_find_all(doc, "//*[@id]"), "id"))
  issues <- character()
  for (path in names(documents)) {
    attrs <- xml2::xml_find_all(documents[[path]], "//@href | //@src")
    for (link in xml2::xml_text(attrs)) {
      if (grepl("^[A-Za-z][A-Za-z0-9+.-]*:|^//", link)) next
      fragment <- if (grepl("#", link, fixed = TRUE)) sub("^[^#]*#", "", link) else ""
      relative <- utils::URLdecode(sub("[?#].*$", "", link))
      target <- if (nzchar(relative)) file.path(dirname(path), relative) else path
      if (dir.exists(target)) target <- file.path(target, "index.html")
      if (!file.exists(target)) {
        issues <- c(issues, paste(basename(path), "-> file mancante:", link))
      } else {
        target <- normalizePath(target)
        if (nzchar(fragment) && target %in% names(ids) && !utils::URLdecode(fragment) %in% ids[[target]]) {
          issues <- c(issues, paste(basename(path), "-> ancora mancante:", link))
        }
      }
    }
  }
  if (length(issues)) stop(paste(issues, collapse = "\n"))
  message(length(files), " file HTML verificati: nessun collegamento locale mancante.")
  invisible(TRUE)
}
