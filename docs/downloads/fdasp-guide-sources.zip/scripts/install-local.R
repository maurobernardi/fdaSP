# Eseguire dalla cartella fdaSP-guide, preferibilmente in una nuova sessione R.
dir.create("library",showWarnings=FALSE)
install.packages("../fdaSP",repos=NULL,type="source",lib="library")
.libPaths(c(normalizePath("library"),.libPaths()))
